
# PLAYER_MARKET_PRICE_ESTIMATOR

Regression pipeline to estimate football player market values using Decision Tree, Random Forest, AdaBoost and XGBoost.
This repository contains preprocessing, feature engineering, training scripts, evaluation and a small sample dataset so you can run it end-to-end.

## Quick start

1. Create virtual environment and install dependencies:

```bash
python -m venv venv
source venv/bin/activate  # Windows: venv\\Scripts\\activate
pip install -r requirements.txt
```

2. Run preprocessing on sample data:
```bash
python src/data_preprocessing.py --input data/raw/sample_players.csv --output data/processed/players_processed.csv
```

3. Train models (uses a small grid for demo):
```bash
python src/train_models.py --input data/processed/players_processed.csv --out_dir models/
```

4. Evaluate saved model:
```bash
python src/evaluate.py --model models/best_model.pkl --test data/processed/test.csv
```

## Repo structure
```
PLAYER_MARKET_PRICE_ESTIMATOR/
├── data/
│   ├── raw/sample_players.csv
│   └── processed/
├── src/
│   ├── data_preprocessing.py
│   ├── feature_engineering.py
│   ├── train_models.py
│   ├── evaluate.py
│   └── utils.py
├── models/
├── notebooks/
│   └── 02_Modeling_stub.ipynb
├── requirements.txt
├── README.md
├── .gitignore
└── LICENSE
```

This repo includes a tiny sample dataset so you can test the pipeline. Replace `data/raw/sample_players.csv` with your full dataset when ready.
