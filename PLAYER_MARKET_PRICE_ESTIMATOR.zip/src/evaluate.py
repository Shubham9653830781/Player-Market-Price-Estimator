
"""Evaluate saved model on test data."""
import pandas as pd
import argparse
import joblib
import numpy as np
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

def main(args):
    model = joblib.load(args.model)
    test = pd.read_csv(args.test)
    features = ['age','goals_per_90','assists_per_90','pos_bucket']
    test = test.dropna(subset=features + ['target'])
    X = test[features]
    y = test['target']
    preds = model.predict(X)
    rmse = mean_squared_error(y, preds, squared=False)
    mae = mean_absolute_error(y, preds)
    r2 = r2_score(y, preds)
    print(f'RMSE: {rmse:.4f} (log1p target units)') 
    print(f'MAE: {mae:.4f} (log1p target units)')
    print(f'R2: {r2:.4f}')
    # To present in original currency, invert log1p:
    preds_orig = np.expm1(preds)
    y_orig = np.expm1(y)
    print('Sample original value comparison:')
    for i in range(min(5, len(preds_orig))):
        print(f'Pred: {preds_orig[i]:.0f} , Actual: {y_orig.iloc[i]:.0f}')

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', required=True)
    parser.add_argument('--test', required=True)
    args = parser.parse_args()
    main(args)
