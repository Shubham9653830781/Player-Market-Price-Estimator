
"""Data preprocessing script for PLAYER_MARKET_PRICE_ESTIMATOR.
Usage:
    python src/data_preprocessing.py --input data/raw/sample_players.csv --output data/processed/players_processed.csv
"""
import pandas as pd
import numpy as np
import argparse
import re
from sklearn.model_selection import train_test_split

def money_to_num(s):
    if pd.isna(s):
        return np.nan
    s = str(s).replace('\u20ac','').replace('€','').strip()
    if s == '':
        return np.nan
    if s.endswith('M'):
        try:
            return float(s[:-1]) * 1e6
        except:
            return np.nan
    if s.endswith('K'):
        try:
            return float(s[:-1]) * 1e3
        except:
            return np.nan
    try:
        return float(s)
    except:
        return np.nan

def basic_clean(df):
    # drop duplicates and unrealistic ages
    df = df.drop_duplicates()
    df = df[df['age'].between(15,50)]
    return df

def preprocess(df):
    df = df.copy()
    df['market_value'] = df['market_value'].apply(money_to_num)
    df = df.dropna(subset=['market_value'])
    # create simple per90 features if minutes_played available
    if 'minutes_played' in df.columns and 'goals' in df.columns:
        df['goals_per_90'] = df['goals'] / (df['minutes_played'] / 90).replace([np.inf, -np.inf], np.nan)
        df['assists_per_90'] = df['assists'] / (df['minutes_played'] / 90).replace([np.inf, -np.inf], np.nan)
    # log1p target to reduce skew
    df['target'] = np.log1p(df['market_value'])
    return df

def main(args):
    df = pd.read_csv(args.input)
    df = basic_clean(df)
    df = preprocess(df)
    # train-test split
    train, test = train_test_split(df, test_size=0.15, random_state=42)
    train.to_csv(args.output.replace('.csv','_train.csv'), index=False)
    test.to_csv(args.output.replace('.csv','_test.csv'), index=False)
    # save full processed file
    df.to_csv(args.output, index=False)
    print('Saved processed files to data/processed/')

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    main(args)
