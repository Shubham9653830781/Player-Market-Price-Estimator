
"""Feature engineering helpers"""
import pandas as pd
import numpy as np

def add_age_features(df):
    df = df.copy()
    df['age_sq'] = df['age'] ** 2
    df['is_young'] = (df['age'] < 23).astype(int)
    return df

def basic_position_bucket(df):
    df = df.copy()
    # crude bucketing example
    mapping = {'ST':'Forward','LW':'Forward','RW':'Forward','CF':'Forward',
               'CM':'Midfielder','CDM':'Midfielder','CAM':'Midfielder',
               'CB':'Defender','LB':'Defender','RB':'Defender','GK':'Goalkeeper'}
    df['pos_bucket'] = df['position'].map(mapping).fillna('Other')
    return df
