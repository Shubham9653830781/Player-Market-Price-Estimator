
"""Train models with a small hyperparameter grid and save best model."""
import pandas as pd
import numpy as np
import argparse
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.ensemble import RandomForestRegressor, AdaBoostRegressor
from sklearn.tree import DecisionTreeRegressor
from xgboost import XGBRegressor
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import mean_squared_error, r2_score
import joblib

def get_preprocessor(num_features, cat_features):
    num_pipe = StandardScaler()
    cat_pipe = OneHotEncoder(handle_unknown='ignore', sparse=False)
    preprocessor = ColumnTransformer([
        ('num', num_pipe, num_features),
        ('cat', cat_pipe, cat_features)
    ])
    return preprocessor

def main(args):
    df = pd.read_csv(args.input)
    # simple feature set for demo
    features = ['age','goals_per_90','assists_per_90']
    cat = ['pos_bucket']
    df = df.dropna(subset=features+['target'])
    X = df[features + cat]
    y = df['target']  # log1p(market_value)
    preprocessor = get_preprocessor(features, cat)
    # model candidates
    models = {
        'rf': RandomForestRegressor(random_state=42),
        'xgb': XGBRegressor(random_state=42, verbosity=0),
        'ada': AdaBoostRegressor(base_estimator=DecisionTreeRegressor(max_depth=4), random_state=42)
    }
    best_score = np.inf
    best_model = None
    for name, model in models.items():
        pipe = Pipeline([('preproc', preprocessor), ('model', model)])
        if name == 'rf':
            param_grid = {'model__n_estimators':[50], 'model__max_depth':[10]}
        elif name == 'xgb':
            param_grid = {'model__n_estimators':[50], 'model__max_depth':[6]}
        else:
            param_grid = {'model__n_estimators':[50]}
        gs = GridSearchCV(pipe, param_grid, cv=3, scoring='neg_root_mean_squared_error', n_jobs=1, verbose=0)
        gs.fit(X, y)
        preds = gs.predict(X)
        rmse = mean_squared_error(y, preds, squared=False)
        print(f"{name} RMSE (train): {rmse:.4f}")
        if rmse < best_score:
            best_score = rmse
            best_model = gs.best_estimator_
    joblib.dump(best_model, args.out_dir.rstrip('/') + '/best_model.pkl')
    print('Saved best model to', args.out_dir)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', required=True)
    parser.add_argument('--out_dir', required=True)
    args = parser.parse_args()
    main(args)
